package com.wuhs.mace;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class MaceCommand implements CommandExecutor, TabCompleter {

    private final WuhsMace plugin;

    public MaceCommand(WuhsMace plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {

        if (args.length < 1 || !args[0].equalsIgnoreCase("give")) {
            sender.sendMessage(Component.text("Usage: /wuhsmace give [player]", NamedTextColor.YELLOW));
            return true;
        }

        Player target;

        if (args.length >= 2) {
            // Give to specified player
            target = Bukkit.getPlayer(args[1]);
            if (target == null) {
                sender.sendMessage(Component.text("Player not found: " + args[1], NamedTextColor.RED));
                return true;
            }
        } else {
            // Give to self
            if (!(sender instanceof Player p)) {
                sender.sendMessage(Component.text("Console must specify a player.", NamedTextColor.RED));
                return true;
            }
            target = p;
        }

        if (!sender.hasPermission("wuhsmace.give")) {
            sender.sendMessage(Component.text("You don't have permission to give Wuh's Mace.", NamedTextColor.RED));
            return true;
        }

        ItemStack mace = MaceItem.create();
        target.getInventory().addItem(mace);

        target.sendMessage(Component.text("You received ", NamedTextColor.GREEN)
                .append(Component.text("Wuh's Mace", NamedTextColor.GOLD))
                .append(Component.text("!", NamedTextColor.GREEN)));

        if (!sender.equals(target)) {
            sender.sendMessage(Component.text("Gave Wuh's Mace to ", NamedTextColor.GREEN)
                    .append(Component.text(target.getName(), NamedTextColor.YELLOW))
                    .append(Component.text(".", NamedTextColor.GREEN)));
        }

        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                      @NotNull String label, @NotNull String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            if ("give".startsWith(args[0].toLowerCase())) completions.add("give");
        } else if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase().startsWith(args[1].toLowerCase())) {
                    completions.add(p.getName());
                }
            }
        }
        return completions;
    }
}
