package com.wuhs.mace;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

public class MaceItem {

    // Custom Model Data value — matches the resource pack entry for "wuhs_mace"
    public static final int CUSTOM_MODEL_DATA = 100001;

    private static final NamespacedKey MACE_KEY =
            new NamespacedKey(WuhsMace.getInstance(), "wuhs_mace");

    /**
     * Creates and returns the Wuh's Mace ItemStack.
     */
    public static ItemStack create() {
        ItemStack item = new ItemStack(Material.MACE);
        ItemMeta meta = item.getItemMeta();

        // Display name — italic is disabled to match vanilla style
        meta.displayName(
            Component.text("Wuh's Mace", NamedTextColor.GOLD)
                     .decoration(TextDecoration.ITALIC, false)
                     .decorate(TextDecoration.BOLD)
        );

        // Lore
        meta.lore(List.of(
            Component.text("Fall to unleash the smash.", NamedTextColor.GRAY)
                     .decoration(TextDecoration.ITALIC, false),
            Component.text("Breaks shields & launches you upward.", NamedTextColor.DARK_AQUA)
                     .decoration(TextDecoration.ITALIC, false),
            Component.text("Cooldown: 30s", NamedTextColor.RED)
                     .decoration(TextDecoration.ITALIC, false)
        ));

        // Custom model data so the resource pack can override the texture
        meta.setCustomModelData(CUSTOM_MODEL_DATA);

        // Tag it so we can identify it reliably later
        meta.getPersistentDataContainer().set(MACE_KEY, PersistentDataType.BYTE, (byte) 1);

        item.setItemMeta(meta);
        return item;
    }

    /**
     * Returns true if the given ItemStack is Wuh's Mace.
     */
    public static boolean isWuhsMace(ItemStack item) {
        if (item == null || item.getType() != Material.MACE) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        return meta.getPersistentDataContainer().has(MACE_KEY, PersistentDataType.BYTE);
    }
}
