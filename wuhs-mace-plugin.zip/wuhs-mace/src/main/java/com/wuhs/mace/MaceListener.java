package com.wuhs.mace;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class MaceListener implements Listener {

    private static final long COOLDOWN_MS = 30_000L;
    private static final int SHIELD_DISABLE_TICKS = 100;
    private static final double LAUNCH_VELOCITY_Y = 1.0;

    private final WuhsMace plugin;
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Map<UUID, BukkitTask> trailTasks = new HashMap<>();

    public MaceListener(WuhsMace plugin) {
        this.plugin = plugin;
    }

    // ── Falling particle trail ──

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        UUID uid = player.getUniqueId();
        boolean holdingMace = MaceItem.isWuhsMace(player.getInventory().getItemInMainHand());
        boolean falling = isFalling(player);

        if (holdingMace && falling) {
            if (!trailTasks.containsKey(uid)) {
                BukkitTask task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
                    if (!player.isOnline()) { stopTrail(uid); return; }
                    if (!isFalling(player) || !MaceItem.isWuhsMace(player.getInventory().getItemInMainHand())) {
                        stopTrail(uid); return;
                    }
                    spawnFallingTrail(player);
                }, 0L, 2L);
                trailTasks.put(uid, task);
            }
        } else {
            stopTrail(uid);
        }
    }

    private void stopTrail(UUID uid) {
        BukkitTask task = trailTasks.remove(uid);
        if (task != null) task.cancel();
    }

    private void spawnFallingTrail(Player player) {
        Location loc = player.getLocation().add(0, 0.8, 0);
        Particle.DustOptions gold = new Particle.DustOptions(Color.fromRGB(255, 165, 0), 1.2f);
        player.getWorld().spawnParticle(Particle.DUST, loc, 6, 0.15, 0.15, 0.15, 0, gold);
        Particle.DustOptions white = new Particle.DustOptions(Color.WHITE, 0.8f);
        player.getWorld().spawnParticle(Particle.DUST, loc, 3, 0.1, 0.1, 0.1, 0, white);
        player.getWorld().spawnParticle(Particle.CRIT, loc, 4, 0.2, 0.2, 0.2, 0.05);
    }

    // ── Hit detection + shield break + launch ──

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMaceHit(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) return;
        ItemStack held = attacker.getInventory().getItemInMainHand();
        if (!MaceItem.isWuhsMace(held)) return;
        if (!isFalling(attacker)) return;
        if (!(event.getEntity() instanceof LivingEntity target)) return;
        if (!isBlocking(target)) return;

        UUID uid = attacker.getUniqueId();
        long now = System.currentTimeMillis();
        if (cooldowns.containsKey(uid)) {
            long remaining = COOLDOWN_MS - (now - cooldowns.get(uid));
            if (remaining > 0) {
                attacker.sendActionBar(Component.text(
                    "Wuh's Mace on cooldown! " + ((remaining / 1000) + 1) + "s remaining.", NamedTextColor.RED));
                event.setCancelled(true);
                return;
            }
        }

        cooldowns.put(uid, now);
        disableShield(target);

        // Launch upward
        Vector vel = attacker.getVelocity();
        vel.setY(LAUNCH_VELOCITY_Y);
        attacker.setVelocity(vel);

        spawnImpactBurst(attacker, target);
        spawnLaunchTrail(attacker);

        attacker.getWorld().playSound(attacker.getLocation(), Sound.ITEM_SHIELD_BREAK, 1.0f, 1.0f);
        attacker.getWorld().playSound(attacker.getLocation(), Sound.ENTITY_PLAYER_ATTACK_STRONG, 1.2f, 0.7f);
        attacker.getWorld().playSound(attacker.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 0.4f, 1.5f);

        attacker.sendActionBar(Component.text("⚡ Shield broken! Launching! ⚡", NamedTextColor.GOLD));

        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (attacker.isOnline()) {
                attacker.sendActionBar(Component.text("Wuh's Mace is ready!", NamedTextColor.GREEN));
                attacker.getWorld().playSound(attacker.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.8f, 2.0f);
            }
        }, COOLDOWN_MS / 50);
    }

    private void spawnImpactBurst(Player attacker, LivingEntity target) {
        Location impactLoc = target.getLocation().add(0, 1.0, 0);
        Particle.DustOptions gold = new Particle.DustOptions(Color.fromRGB(255, 200, 0), 1.8f);
        attacker.getWorld().spawnParticle(Particle.DUST, impactLoc, 40, 0.6, 0.6, 0.6, 0, gold);
        Particle.DustOptions red = new Particle.DustOptions(Color.fromRGB(220, 50, 50), 1.2f);
        attacker.getWorld().spawnParticle(Particle.DUST, impactLoc, 20, 0.4, 0.4, 0.4, 0, red);
        attacker.getWorld().spawnParticle(Particle.CRIT, impactLoc, 25, 0.5, 0.5, 0.5, 0.3);
        attacker.getWorld().spawnParticle(Particle.SWEEP_ATTACK, impactLoc, 5, 0.3, 0.2, 0.3, 0.1);
        attacker.getWorld().spawnParticle(Particle.LARGE_SMOKE, impactLoc, 8, 0.4, 0.1, 0.4, 0.05);
    }

    private void spawnLaunchTrail(Player attacker) {
        final int[] tick = {0};
        plugin.getServer().getScheduler().runTaskTimer(plugin, task -> {
            if (!attacker.isOnline() || tick[0]++ >= 15) { task.cancel(); return; }
            Location loc = attacker.getLocation().add(0, 0.3, 0);
            Particle.DustOptions brightGold = new Particle.DustOptions(Color.fromRGB(255, 230, 80), 1.5f);
            attacker.getWorld().spawnParticle(Particle.DUST, loc, 8, 0.2, 0.05, 0.2, 0, brightGold);
            attacker.getWorld().spawnParticle(Particle.FIREWORK, loc, 5, 0.2, 0.1, 0.2, 0.05);
            attacker.getWorld().spawnParticle(Particle.CRIT, loc, 3, 0.15, 0.05, 0.15, 0.1);
        }, 1L, 1L);
    }

    // ── Helpers ──

    private boolean isFalling(Player player) {
        return player.getFallDistance() > 0.0f || player.getVelocity().getY() < -0.1;
    }

    private boolean isBlocking(LivingEntity entity) {
        if (entity instanceof Player target) return target.isBlocking();
        ItemStack offhand = entity.getEquipment() != null ? entity.getEquipment().getItemInOffHand() : null;
        return offhand != null && offhand.getType() == Material.SHIELD;
    }

    private void disableShield(LivingEntity entity) {
        if (entity instanceof Player target) {
            target.setCooldown(Material.SHIELD, SHIELD_DISABLE_TICKS);
        } else {
            if (entity.getEquipment() == null) return;
            ItemStack offhand = entity.getEquipment().getItemInOffHand();
            if (offhand.getType() == Material.SHIELD) {
                entity.getEquipment().setItemInOffHand(new ItemStack(Material.AIR));
                plugin.getServer().getScheduler().runTaskLater(plugin,
                    () -> entity.getEquipment().setItemInOffHand(offhand), SHIELD_DISABLE_TICKS);
            }
        }
    }
}
