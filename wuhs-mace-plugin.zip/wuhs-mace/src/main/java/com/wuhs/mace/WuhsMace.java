package com.wuhs.mace;

import org.bukkit.plugin.java.JavaPlugin;

public class WuhsMace extends JavaPlugin {

    private static WuhsMace instance;

    @Override
    public void onEnable() {
        instance = this;

        getServer().getPluginManager().registerEvents(new MaceListener(this), this);
        getCommand("wuhsmace").setExecutor(new MaceCommand(this));

        getLogger().info("Wuh's Mace has been enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("Wuh's Mace has been disabled.");
    }

    public static WuhsMace getInstance() {
        return instance;
    }
}
